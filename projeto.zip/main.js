
const App = () => React.createElement("h1", null, "Projeto funcionando!");
ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
